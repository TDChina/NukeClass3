## init.py
## loaded by nuke before menu.py

nuke.pluginAddPath('./AP_gizmos')
